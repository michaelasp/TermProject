Project Description:
My project is one where people may create an account which they can then access. 
The app will allow people to upload gpx files which I will then run some metrics on. 
I hold these records in order to let users view their trails and various segments. 
it will rank all the segments in each gpx file and recommend based upon what type of ride the user wants. 

How To Run:
Simply run __init__.py

Libraries:
sqlite3 and gpxpy are dependencies which can both be installed with pip with the exact names given

Shortcuts:
No shortcuts but backspace returns to previous page, arrow keys for pages/ suggestions and everything
else just click on.